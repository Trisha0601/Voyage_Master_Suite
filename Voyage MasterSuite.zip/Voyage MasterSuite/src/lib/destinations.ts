import santorini from "@/assets/place-santorini.jpg";
import bali from "@/assets/place-bali.jpg";
import swiss from "@/assets/place-swiss.jpg";
import kyoto from "@/assets/place-kyoto.jpg";
import maldives from "@/assets/place-maldives.jpg";
import dubai from "@/assets/place-dubai.jpg";

export type Destination = {
  id: string;
  name: string;
  country: string;
  image: string;
  price: number;
  rating: number;
  days: number;
  tag: "Beach" | "Mountain" | "City" | "Cultural";
  description: string;
};

export const destinations: Destination[] = [
  { id: "santorini", name: "Santorini", country: "Greece", image: santorini, price: 1299, rating: 4.9, days: 6, tag: "Beach", description: "Iconic whitewashed cliffside villages and crystal blue Aegean waters." },
  { id: "bali", name: "Bali", country: "Indonesia", image: bali, price: 999, rating: 4.8, days: 8, tag: "Cultural", description: "Lush rice terraces, ancient temples, and serene jungle retreats." },
  { id: "swiss", name: "Swiss Alps", country: "Switzerland", image: swiss, price: 1799, rating: 4.9, days: 7, tag: "Mountain", description: "Snow-capped peaks, cozy chalets, and unforgettable alpine adventures." },
  { id: "kyoto", name: "Kyoto", country: "Japan", image: kyoto, price: 1499, rating: 4.9, days: 9, tag: "Cultural", description: "Cherry blossoms, historic temples, and timeless Japanese tradition." },
  { id: "maldives", name: "Maldives", country: "Maldives", image: maldives, price: 2199, rating: 5.0, days: 5, tag: "Beach", description: "Overwater villas above the bluest lagoons you will ever see." },
  { id: "dubai", name: "Dubai", country: "UAE", image: dubai, price: 1399, rating: 4.7, days: 5, tag: "City", description: "Futuristic skyline, golden deserts, and world-class luxury." },
];
