import { supabase } from "@/integrations/supabase/client";

export type Booking = {
  id: string;
  destinationId: string;
  destinationName: string;
  travelers: number;
  startDate: string;
  totalPrice: number;
  status: string;
  createdAt: string;
};

export async function getBookings(userId: string): Promise<Booking[]> {
  const { data, error } = await supabase
    .from("bookings")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map((b) => ({
    id: b.id,
    destinationId: b.destination_id,
    destinationName: b.destination_name,
    travelers: b.travelers,
    startDate: b.start_date,
    totalPrice: Number(b.total_price),
    status: b.status,
    createdAt: b.created_at,
  }));
}

export async function addBooking(
  userId: string,
  b: Omit<Booking, "id" | "createdAt" | "status"> & { status?: string },
): Promise<Booking> {
  const { data, error } = await supabase
    .from("bookings")
    .insert({
      user_id: userId,
      destination_id: b.destinationId,
      destination_name: b.destinationName,
      travelers: b.travelers,
      start_date: b.startDate,
      total_price: b.totalPrice,
      status: b.status ?? "Confirmed",
    })
    .select()
    .single();
  if (error) throw error;
  return {
    id: data.id,
    destinationId: data.destination_id,
    destinationName: data.destination_name,
    travelers: data.travelers,
    startDate: data.start_date,
    totalPrice: Number(data.total_price),
    status: data.status,
    createdAt: data.created_at,
  };
}
