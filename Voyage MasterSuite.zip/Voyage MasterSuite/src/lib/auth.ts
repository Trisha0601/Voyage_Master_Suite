import { supabase } from "@/integrations/supabase/client";

export type User = { id: string; name: string; email: string };

export async function getUser(): Promise<User | null> {
  const { data } = await supabase.auth.getUser();
  if (!data.user) return null;
  const meta = (data.user.user_metadata || {}) as { name?: string };
  return {
    id: data.user.id,
    email: data.user.email ?? "",
    name: meta.name ?? data.user.email?.split("@")[0] ?? "Traveler",
  };
}

export async function signup(name: string, email: string, password: string) {
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { name },
      emailRedirectTo: `${window.location.origin}/home`,
    },
  });
  if (error) throw error;
}

export async function login(email: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
}

export async function logout() {
  await supabase.auth.signOut();
}
