import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getUser, logout, type User } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Plane, LogOut } from "lucide-react";

const links = [
  { to: "/home", label: "Home" },
  { to: "/gallery", label: "Gallery" },
  { to: "/blog", label: "Blog" },
  { to: "/booking", label: "Booking" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [user, setU] = useState<User | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    getUser().then(setU);
    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      getUser().then(setU);
    });
    return () => subscription.unsubscribe();
  }, []);

  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-lg">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/home" className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-hero text-primary-foreground">
            <Plane className="h-5 w-5" />
          </div>
          <span className="font-display text-lg font-semibold">Voyage<span className="text-gradient">MasterSuite</span></span>
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          {links.map(l => (
            <Link
              key={l.to}
              to={l.to}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              activeProps={{ className: "rounded-md px-3 py-2 text-sm font-medium text-foreground bg-muted" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          {user ? (
            <>
              <span className="hidden text-sm text-muted-foreground sm:inline">Hi, {user.name.split(" ")[0]}</span>
              <Button variant="ghost" size="sm" onClick={async () => { await logout(); navigate({ to: "/" }); }}>
                <LogOut className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/" })}>Login</Button>
              <Button size="sm" onClick={() => navigate({ to: "/signup" })} className="bg-gradient-hero">Sign Up</Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
