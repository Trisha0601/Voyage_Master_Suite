import { Link } from "@tanstack/react-router";
import { Plane } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border bg-muted/30 mt-24">
      <div className="container mx-auto grid gap-8 px-4 py-12 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-hero text-primary-foreground">
              <Plane className="h-4 w-4" />
            </div>
            <span className="font-display font-semibold">VoyageMasterSuite</span>
          </div>
          <p className="text-sm text-muted-foreground">Your trusted partner for unforgettable journeys around the world.</p>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold">Explore</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/gallery" className="hover:text-foreground">Destinations</Link></li>
            <li><Link to="/booking" className="hover:text-foreground">Book a Tour</Link></li>
            <li><Link to="/blog" className="hover:text-foreground">Travel Blog</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold">Company</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/about" className="hover:text-foreground">About Us</Link></li>
            <li><Link to="/contact" className="hover:text-foreground">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold">Contact</h4>
          <p className="text-sm text-muted-foreground">voyagemaster@gmail.com<br/>+91 1234567890</p>
        </div>
      </div>
      <div className="border-t border-border py-4 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} VoyageMasterSuite. All rights reserved.
      </div>
    </footer>
  );
}
