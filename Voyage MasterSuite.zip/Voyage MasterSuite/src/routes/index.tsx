import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { login } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plane } from "lucide-react";
import hero from "@/assets/hero-travel.jpg";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Login — VoyageMasterSuite" }, { name: "description", content: "Sign in to plan, book and manage your trips." }] }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/home" });
    });
  }, [navigate]);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      await login(email, password);
      navigate({ to: "/home" });
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden lg:block">
        <img src={hero} alt="Tropical paradise" className="absolute inset-0 h-full w-full object-cover" width={1920} height={1280} />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/70 via-primary/30 to-accent/60" />
        <div className="relative z-10 flex h-full flex-col justify-between p-12 text-primary-foreground">
          <div className="flex items-center gap-2">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-white/20 backdrop-blur">
              <Plane className="h-5 w-5" />
            </div>
            <span className="font-display text-lg font-semibold">VoyageMasterSuite</span>
          </div>
          <div>
            <h1 className="font-display text-5xl font-semibold leading-tight">Where will you<br/>wander next?</h1>
            <p className="mt-4 max-w-md text-white/90">Discover curated journeys, book in seconds, and manage every detail from one elegant dashboard.</p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden flex items-center gap-2">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-hero text-primary-foreground">
              <Plane className="h-5 w-5" />
            </div>
            <span className="font-display text-lg font-semibold">VoyageMasterSuite</span>
          </div>
          <h2 className="font-display text-3xl font-semibold">Welcome back</h2>
          <p className="mt-2 text-sm text-muted-foreground">Sign in to continue planning your next adventure.</p>

          <form onSubmit={onSubmit} className="mt-8 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} required />
            </div>
            {err && <p className="text-sm text-destructive">{err}</p>}
            <Button type="submit" disabled={loading} className="w-full bg-gradient-hero">
              {loading ? "Signing in..." : "Sign In"}
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              New here? <Link to="/signup" className="text-primary underline">Create an account</Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
