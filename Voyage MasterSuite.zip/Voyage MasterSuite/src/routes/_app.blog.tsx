import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, User } from "lucide-react";
import santorini from "@/assets/place-santorini.jpg";
import bali from "@/assets/place-bali.jpg";
import swiss from "@/assets/place-swiss.jpg";
import kyoto from "@/assets/place-kyoto.jpg";

export const Route = createFileRoute("/_app/blog")({
  head: () => ({ meta: [{ title: "Blog — Customer Recent Blogs" }, { name: "description", content: "Stories, tips and recent posts from fellow travelers." }] }),
  component: BlogPage,
});

const posts = [
  { title: "10 Days in Bali: A Slow Travel Diary", author: "Priya S.", date: "May 12, 2026", tag: "Cultural", image: bali, excerpt: "From sunrise yoga in Ubud to surfing in Canggu — here's how to plan a meaningful Bali trip." },
  { title: "Skiing the Swiss Alps on a Budget", author: "Vivek Nair", date: "May 03, 2026", tag: "Mountain", image: swiss, excerpt: "Yes, the Alps can be affordable. My honest breakdown of a 6-day chalet getaway." },
  { title: "Santorini Without the Crowds", author: "Riya Menon", date: "Apr 27, 2026", tag: "Beach", image: santorini, excerpt: "The shoulder-season hack that gave us the island almost to ourselves." },
  { title: "Cherry Blossom Season in Kyoto", author: "Ananya Sharma", date: "Apr 14, 2026", tag: "Cultural", image: kyoto, excerpt: "A week-long route through temples, gardens, and the best matcha cafés." },
];

function BlogPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl">
        <p className="text-sm font-medium text-primary">Blog</p>
        <h1 className="font-display text-5xl font-semibold mt-2">Customer Recent Blogs</h1>
        <p className="mt-3 text-muted-foreground">Real stories and useful tips from travelers like you.</p>
      </div>

      <div className="mt-10 grid gap-6 md:grid-cols-2">
        {posts.map(p => (
          <Card key={p.title} className="overflow-hidden border-0 shadow-card hover:shadow-elegant transition-all pt-0">
            <div className="aspect-[16/9] overflow-hidden">
              <img src={p.image} alt={p.title} loading="lazy" className="h-full w-full object-cover" />
            </div>
            <div className="p-6">
              <Badge variant="secondary">{p.tag}</Badge>
              <h3 className="font-display text-2xl font-semibold mt-3">{p.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{p.excerpt}</p>
              <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><User className="h-3.5 w-3.5" />{p.author}</span>
                <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" />{p.date}</span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
