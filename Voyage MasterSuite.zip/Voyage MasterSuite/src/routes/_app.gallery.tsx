import { createFileRoute, Link } from "@tanstack/react-router";
import { destinations } from "@/lib/destinations";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, MapPin } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/_app/gallery")({
  head: () => ({ meta: [{ title: "Gallery — Popular Places" }, { name: "description", content: "Browse the most popular destinations curated for you." }] }),
  component: GalleryPage,
});

const filters = ["All", "Beach", "Mountain", "City", "Cultural"] as const;

function GalleryPage() {
  const [active, setActive] = useState<(typeof filters)[number]>("All");
  const items = active === "All" ? destinations : destinations.filter(d => d.tag === active);

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl">
        <p className="text-sm font-medium text-primary">Gallery</p>
        <h1 className="font-display text-5xl font-semibold mt-2">Popular Places</h1>
        <p className="mt-3 text-muted-foreground">Explore our hand-picked destinations across every kind of escape.</p>
      </div>

      <div className="mt-8 flex flex-wrap gap-2">
        {filters.map(f => (
          <Button key={f} variant={active === f ? "default" : "outline"} size="sm" onClick={() => setActive(f)} className={active === f ? "bg-gradient-hero" : ""}>
            {f}
          </Button>
        ))}
      </div>

      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(d => (
          <Card key={d.id} className="overflow-hidden border-0 shadow-card hover:shadow-elegant transition-all hover:-translate-y-1 pt-0">
            <div className="relative aspect-[4/3] overflow-hidden">
              <img src={d.image} alt={d.name} loading="lazy" className="h-full w-full object-cover transition-transform hover:scale-105" />
              <Badge className="absolute top-3 left-3 bg-background/90 text-foreground">{d.tag}</Badge>
              <div className="absolute bottom-3 right-3 flex items-center gap-1 rounded-full bg-background/90 px-2 py-1 text-xs">
                <Star className="h-3 w-3 fill-accent text-accent" />{d.rating}
              </div>
            </div>
            <div className="p-5">
              <h3 className="font-display text-xl font-semibold">{d.name}</h3>
              <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1"><MapPin className="h-3.5 w-3.5" />{d.country} · {d.days} days</p>
              <p className="text-sm text-muted-foreground mt-3 line-clamp-2">{d.description}</p>
              <div className="mt-4 flex items-center justify-between">
                <span className="font-display text-lg font-semibold">Rs.{d.price}</span>
                <Button size="sm" asChild className="bg-gradient-hero"><Link to="/booking">Book Now</Link></Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
