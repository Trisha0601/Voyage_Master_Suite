import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Globe, Heart, Sparkles, Users } from "lucide-react";

export const Route = createFileRoute("/_app/about")({
  head: () => ({ meta: [{ title: "About Us — VoyageMasterSuite" }, { name: "description", content: "Our mission, values and the team behind VoyageMasterSuite." }] }),
  component: AboutPage,
});

const stats = [
  { icon: Users, value: "10k+", label: "Happy travelers" },
  { icon: Globe, value: "50+", label: "Destinations" },
  { icon: Sparkles, value: "4.5", label: "Average rating" },
  { icon: Heart, value: "03 yrs", label: "In business" },
];

function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl">
        <p className="text-sm font-medium text-primary">About Us</p>
        <h1 className="font-display text-5xl font-semibold mt-2">We design journeys that feel like home — anywhere in the world.</h1>
        <p className="mt-5 text-lg text-muted-foreground">VoyageMasterSuite was born from a simple belief: travel should be effortless, personal, and unforgettable. From booking workflows to expense tracking, we built every part of the platform so travelers can focus on the experience, not the logistics.</p>
      </div>

      <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map(s => (
          <Card key={s.label} className="p-6 border-0 shadow-card bg-gradient-card">
            <div className="grid h-11 w-11 place-items-center rounded-lg bg-gradient-hero text-primary-foreground">
              <s.icon className="h-5 w-5" />
            </div>
            <p className="font-display text-3xl font-semibold mt-4">{s.value}</p>
            <p className="text-sm text-muted-foreground">{s.label}</p>
          </Card>
        ))}
      </div>

      <div className="mt-16 grid gap-10 md:grid-cols-2">
        <div>
          <h2 className="font-display text-3xl font-semibold">Our mission</h2>
          <p className="mt-3 text-muted-foreground">Streamline booking, approvals, expenses, and reporting into one beautiful workflow — reducing manual effort while improving operational efficiency for travelers and teams alike.</p>
        </div>
        <div>
          <h2 className="font-display text-3xl font-semibold">Our approach</h2>
          <p className="mt-3 text-muted-foreground">A robust database, seamless integrations, and automated workflows powered by a purpose-built controller. The result: faster requests, real-time updates, and a system you can trust.</p>
        </div>
      </div>
    </div>
  );
}
