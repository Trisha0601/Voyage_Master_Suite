import { createFileRoute, Link } from "@tanstack/react-router";
import { destinations } from "@/lib/destinations";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Calendar, Wallet, Hotel, Compass, Quote, ArrowRight } from "lucide-react";
import hero from "@/assets/hero-travel.jpg";

export const Route = createFileRoute("/_app/home")({
  head: () => ({ meta: [{ title: "Home — VoyageMasterSuite" }, { name: "description", content: "Explore featured destinations, services and reviews." }] }),
  component: HomePage,
});

const services = [
  { icon: Wallet, title: "Suitable Price", desc: "Best-in-class pricing with transparent fees and zero hidden charges." },
  { icon: Hotel, title: "Luxurious Hotel", desc: "Hand-picked premium stays from boutique resorts to 5-star icons." },
  { icon: Compass, title: "Travel Guide", desc: "Dedicated local experts to craft your perfect day-by-day itinerary." },
];

const reviews = [
  { name: "Priyaka", trip: "Maldives", rating: 5, text: "Effortless booking, dreamy stay. The overwater villa was beyond expectation." },
  { name: "Jiya Sharma", trip: "Kyoto", rating: 5, text: "Loved the curated itinerary — temples, tea ceremonies, perfect timing." },
  { name: "Satyam. K", trip: "Swiss Alps", rating: 4, text: "Stunning chalets and a flawless ski package. Will book again next winter." },
];

function HomePage() {
  const featured = destinations.slice(0, 3);

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <img src={hero} alt="Tropical paradise" className="absolute inset-0 h-full w-full object-cover" width={1920} height={1280} />
        <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/40 to-background" />
        <div className="container relative mx-auto px-4 py-32 md:py-44">
          <Badge variant="secondary" className="mb-4">Welcome back</Badge>
          <h1 className="font-display text-5xl font-semibold md:text-7xl max-w-3xl">Plan it. Book it. <span className="text-gradient">Live it.</span></h1>
          <p className="mt-6 max-w-xl text-lg text-foreground/80">From hidden beaches to alpine peaks, manage every step of your journey in one elegant suite.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg" className="bg-gradient-hero" asChild>
              <Link to="/booking">Book a Tour <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/gallery">Browse Gallery</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Places */}
      <section className="container mx-auto px-4 py-20">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-sm font-medium text-primary">Featured Places</p>
            <h2 className="font-display text-4xl font-semibold mt-1">Trending right now</h2>
          </div>
          <Link to="/gallery" className="hidden md:flex items-center gap-1 text-sm font-medium text-primary hover:underline">
            View all <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {featured.map(d => (
            <Card key={d.id} className="overflow-hidden border-0 shadow-card hover:shadow-elegant transition-all hover:-translate-y-1 pt-0">
              <div className="relative aspect-[4/3] overflow-hidden">
                <img src={d.image} alt={d.name} loading="lazy" className="h-full w-full object-cover transition-transform hover:scale-105" />
                <Badge className="absolute top-3 left-3 bg-background/90 text-foreground">{d.tag}</Badge>
              </div>
              <div className="p-5">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-xl font-semibold">{d.name}</h3>
                  <span className="flex items-center gap-1 text-sm"><Star className="h-3.5 w-3.5 fill-accent text-accent" />{d.rating}</span>
                </div>
                <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1"><MapPin className="h-3.5 w-3.5" />{d.country}</p>
                <p className="text-sm text-muted-foreground mt-3 line-clamp-2">{d.description}</p>
                <div className="mt-4 flex items-center justify-between">
                  <span className="font-display text-lg font-semibold">Rs.{d.price}<span className="text-sm font-normal text-muted-foreground">/person</span></span>
                  <Button size="sm" variant="secondary" asChild>
                    <Link to="/booking">Book</Link>
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Services */}
      <section className="bg-muted/40 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-sm font-medium text-primary">Our Services</p>
            <h2 className="font-display text-4xl font-semibold mt-1">Everything for a perfect trip</h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {services.map(s => (
              <Card key={s.title} className="p-8 border-0 bg-gradient-card shadow-card text-center">
                <div className="mx-auto grid h-14 w-14 place-items-center rounded-xl bg-gradient-hero text-primary-foreground">
                  <s.icon className="h-6 w-6" />
                </div>
                <h3 className="font-display text-xl font-semibold mt-5">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="text-sm font-medium text-primary">Reviews</p>
          <h2 className="font-display text-4xl font-semibold mt-1">Loved by travelers worldwide</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {reviews.map(r => (
            <Card key={r.name} className="p-6 border-0 shadow-card">
              <Quote className="h-7 w-7 text-primary/40" />
              <p className="mt-3 text-sm text-foreground/90">"{r.text}"</p>
              <div className="mt-5 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-sm">{r.name}</p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" />{r.trip}</p>
                </div>
                <div className="flex gap-0.5">
                  {Array.from({ length: r.rating }).map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-accent text-accent" />)}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>
    </>
  );
}
