import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Instagram, Mail, MapPin, Phone } from "lucide-react";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/contact")({
  head: () => ({ meta: [{ title: "Contact Us — VoyageMasterSuite" }, { name: "description", content: "Get in touch with the VoyageMasterSuite team." }] }),
  component: ContactPage,
});

function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    toast.success("Message sent!", { description: "We'll get back to you within 24 hours." });
    setName(""); setEmail(""); setMsg("");
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl">
        <p className="text-sm font-medium text-primary">Contact</p>
        <h1 className="font-display text-5xl font-semibold mt-2">Let's plan something amazing.</h1>
        <p className="mt-3 text-muted-foreground">Questions, custom itineraries, or partnerships — drop us a line.</p>
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_360px]">
        <Card className="p-6 border-0 shadow-card">
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2"><Label htmlFor="n">Name</Label><Input id="n" value={name} onChange={e => setName(e.target.value)} required /></div>
              <div className="space-y-2"><Label htmlFor="e">Email</Label><Input id="e" type="email" value={email} onChange={e => setEmail(e.target.value)} required /></div>
            </div>
            <div className="space-y-2"><Label htmlFor="m">Message</Label><Textarea id="m" rows={6} value={msg} onChange={e => setMsg(e.target.value)} required /></div>
            <Button type="submit" className="bg-gradient-hero">Send message</Button>
          </form>
        </Card>

        <div className="space-y-4">
          {[
            { icon: Mail, label: "Email", value: "voyagemaster@gmail.com" },
            { icon: Phone, label: "Phone", value: "+91 1234567890" },
            { icon: MapPin, label: "Location", value: "Kasarvadavali, Thane(Mumbai)" },
          ].map(c => (
            <Card key={c.label} className="p-5 border-0 shadow-card flex items-center gap-4">
              <div className="grid h-11 w-11 place-items-center rounded-lg bg-gradient-hero text-primary-foreground">
                <c.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wide text-muted-foreground">{c.label}</p>
                <p className="font-medium">{c.value}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
