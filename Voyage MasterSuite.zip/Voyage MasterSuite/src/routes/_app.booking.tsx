import { createFileRoute } from "@tanstack/react-router";
import { destinations } from "@/lib/destinations";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { addBooking, getBookings, type Booking } from "@/lib/bookings";
import { getUser } from "@/lib/auth";
import { CreditCard, CheckCircle2, MapPin } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/booking")({
  head: () => ({ meta: [{ title: "Booking — Book Your Tour & Payment" }, { name: "description", content: "Book your tour and complete secure payment." }] }),
  component: BookingPage,
});

function BookingPage() {
  const [destId, setDestId] = useState(destinations[0].id);
  const [travelers, setTravelers] = useState(0);
  const [startDate, setStartDate] = useState(() => {
    const d = new Date(); d.setDate(d.getDate() + 14);
    return d.toISOString().slice(0, 10);
  });
  const [card, setCard] = useState("1234 5678 9123 456");
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [userId, setUserId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const dest = useMemo(() => destinations.find(d => d.id === destId)!, [destId]);
  const total = dest.price * travelers;

  useEffect(() => {
    getUser().then((u) => {
      if (!u) return;
      setUserId(u.id);
      getBookings(u.id).then(setBookings).catch((e) => toast.error(e.message));
    });
  }, []);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!userId) return;
    setSubmitting(true);
    try {
      await addBooking(userId, {
        destinationId: dest.id,
        destinationName: `${dest.name}, ${dest.country}`,
        travelers,
        startDate,
        totalPrice: total,
      });
      setBookings(await getBookings(userId));
      toast.success("Booking confirmed!", { description: `${dest.name} for ${travelers} traveler(s).` });
    } catch (err: any) {
      toast.error("Booking failed", { description: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl">
        <p className="text-sm font-medium text-primary">Booking</p>
        <h1 className="font-display text-5xl font-semibold mt-2">Book Your Tour & Payment</h1>
        <p className="mt-3 text-muted-foreground">Choose a destination, pick dates, and check out securely.</p>
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_400px]">
        <Card className="p-6 border-0 shadow-card">
          <form onSubmit={onSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label>Destination</Label>
              <Select value={destId} onValueChange={setDestId}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {destinations.map(d => (
                    <SelectItem key={d.id} value={d.id}>{d.name}, {d.country} — Rs.{d.price}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="date">Start date</Label>
                <Input id="date" type="date" value={startDate} onChange={e => setStartDate(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="trav">Travelers</Label>
                <Input id="trav" type="number" min={1} max={10} value={travelers} onChange={e => setTravelers(Number(e.target.value))} required />
              </div>
            </div>
            <div className="pt-3 border-t">
              <Label className="flex items-center gap-2"><CreditCard className="h-4 w-4" />Card number</Label>
              <Input className="mt-2" value={card} onChange={e => setCard(e.target.value)} placeholder="1234 5678 9012 3456" required />
              <p className="text-xs text-muted-foreground mt-2">Demo payment — no real charge is made.</p>
            </div>
            <Button type="submit" disabled={submitting} className="w-full bg-gradient-hero" size="lg">
              <CheckCircle2 className="mr-2 h-4 w-4" /> {submitting ? "Processing..." : `Confirm & Pay Rs.{total}`}
            </Button>
          </form>
        </Card>

        <Card className="p-6 border-0 bg-gradient-card shadow-card h-fit">
          <div className="overflow-hidden rounded-lg">
            <img src={dest.image} alt={dest.name} loading="lazy" className="aspect-video w-full object-cover" />
          </div>
          <Badge className="mt-4" variant="secondary">{dest.tag}</Badge>
          <h3 className="font-display text-2xl font-semibold mt-2">{dest.name}</h3>
          <p className="text-sm text-muted-foreground flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{dest.country} · {dest.days} days</p>
          <p className="text-sm text-muted-foreground mt-3">{dest.description}</p>
          <div className="mt-5 space-y-2 text-sm border-t pt-4">
            <div className="flex justify-between"><span className="text-muted-foreground">Per person</span><span>Rs.{dest.price}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Travelers</span><span>× {travelers}</span></div>
            <div className="flex justify-between font-display text-lg font-semibold pt-2 border-t"><span>Total</span><span>Rs.{total}</span></div>
          </div>
        </Card>
      </div>

      {bookings.length > 0 && (
        <div className="mt-16">
          <h2 className="font-display text-3xl font-semibold">Your Bookings</h2>
          <div className="mt-6 grid gap-4">
            {bookings.map(b => (
              <Card key={b.id} className="p-5 border-0 shadow-card flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="font-semibold">{b.destinationName}</p>
                  <p className="text-sm text-muted-foreground">{b.travelers} traveler(s) · starts {b.startDate}</p>
                </div>
                <div className="flex items-center gap-4">
                  <Badge className="bg-green-500/10 text-green-700 border-green-200">{b.status}</Badge>
                  <span className="font-display text-lg font-semibold">Rs.{b.totalPrice}</span>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
